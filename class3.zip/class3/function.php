<?php
if(isset($_POST['create'])){
  $sname=$_POST['sname'];
  $fname=$_POST['fname'];
  $pass=$_POST['pass'];
  $email=$_POST['email'];
  echo $sname."<br>";
  echo $fname."<br>";
  echo $pass."<br>";
  echo $email."<br>";
}

?>