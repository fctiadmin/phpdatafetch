 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>raw php</title>
 </head>
 <body>
    <?php
   
    $father_name="jamal islam";
    $course="Office Application";
    $session="January-June";
    $mobile="8801928248173";
    
    ?>
    <table border="1" width="400">
<tr>
    <td>Name</td>
    <td>Father Name</td>
    <td>Course</td>
    <td>Session</td>
    <td>Mobile</td>
</tr>
<tr>
    <td><?php if(isset($name)){echo ucwords(strtolower($name));} ?></td>
    <td><?=ucwords(strtolower($father_name))?></td>
    <td><?=$course?></td>
    <td><?=$session?></td>
    <td><?=$mobile?></td>
</tr>


    </table>
 </body>
 </html>